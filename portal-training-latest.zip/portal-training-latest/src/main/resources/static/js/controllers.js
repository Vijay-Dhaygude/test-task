training.controller('TableCtrl', function ($scope, $http) {
    /*put your js code here */
		
        $http.get('http://data.ssb.no/api/v0/dataset/1106.json?lang=en').   
        then (function succes(response) {
            $scope.dataset = response.data;
        }, function failuer(response) {
            $scope.dataset = response.statusText;
        });


        //get spring application  api data
        $http.get('rest/greeting').   
        then(function(response) {
            $scope.springbootserviceData = response.data;
        });

});