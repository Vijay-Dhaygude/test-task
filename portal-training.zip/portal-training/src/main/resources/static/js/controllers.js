training.controller('TableCtrl', function ($scope, $http) {
    /*put your js code here */
});