describe('Services', function() {
  var greetingData = [...];

  // Add a custom equality tester before each test
  beforeEach(function() {
    jasmine.addCustomEqualityTester(angular.equals);
  });

  // Load the module that contains the `greeting` service before each test
 
  // Verify that there are no outstanding expectations or requests after each test
  afterEach(function () {
    $httpBackend.verifyNoOutstandingExpectation();
    $httpBackend.verifyNoOutstandingRequest();
  });

  it('should fetch the greeting data from `/greeting/greeting.json`', function() {
    var greeting = greeting.query();

    expect(greetings).toEqual([]);

    $httpBackend.flush();
    expect(greetings).toEqual(greetingData);
  });

});