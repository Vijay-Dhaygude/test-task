training.controller('TableCtrl', function ($scope, $http) {
    /*put your js code here */

    //$http.get('http://data.ssb.no/api/v0/dataset/1106.json?lang=en')
    	//get external  api data
		$http.get('https://jsonplaceholder.typicode.com/todos').   
        then(function(response) {
            $scope.dataset = response.data;
        });


        //get spring application  api data
        $http.get('rest/greeting').   
        then(function(response) {
            $scope.springbootserviceData = response.data;
        });

});